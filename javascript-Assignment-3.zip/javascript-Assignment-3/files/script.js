let cities = ["Faisalabad", "Lahor", "Karachi", "Islamabad", "Burewala", "Shakhupura", "Kashmir"]

document.getElementById('SimpleAlert').onclick = function () {
  alert('Simple Alert')
  document.getElementById('Result').innerHTML = 'Simple Alert'
  console.log();
}

document.getElementById('printName').onclick = function () {

  let MyName = document.getElementById('InputSearch').value

  if (MyName === '') {
    alert('Please Enter your Name')
    return;
  }
  document.getElementById('Result').innerHTML = MyName

}

document.getElementById('loop').onclick = function () {
  for (let i = 0; i < cities.length; i++) {
    document.getElementById('Result').innerHTML += cities[i] + '<br />'
  }
}

function addCity() {

  let inputField = document.getElementById('InputSearch').value
  if (!inputField) {
    alert('Add your city name')
    return;
  }
  
  let toLowerCase = inputField.slice(1).toLowerCase()
  let toUpperCase = inputField.slice(0,1).toUpperCase()
  let alletters   = toUpperCase + toLowerCase 
  
  
  console.log(alletters);
  
  let addCity = false
  addCity = cities.includes(alletters)
  
  
  if (addCity) {
    addCity = true
    alert('city is already found')
    return;
  }else{
    cities.push(alletters)
    document.getElementById('Result').innerHTML = 'add successfully' + ' ' + alletters
    
  }}

  clearOutput = () => {
    document.getElementById('Result').innerHTML = ''
  }
  clearInput = () => {
    document.getElementById('InputSearch').value = ''
  }





























// document.getElementById('SimpleAlert').onclick = function () {
//     alert('Simple alert')
//   document.getElementById('Result').innerHTML = 'Simple alert'
// }

// document.getElementById('printName').onclick = function () {
//   let printName = document.getElementById('InputSearch').value
//   if (printName < 3) {
//    return alert('plaese enter your name')
//   }
//   document.getElementById('Result').innerHTML = printName
// }

// document.getElementById('loop').onclick = function () {
//   for (let i = 0; i < cities.length  ; i++) {
//     document.getElementById('Result').innerHTML += cities[i]+' <br>'
    
//   }
// }

// addCity = () => {
//   let inputField = document.getElementById('InputSearch').value
//   if (inputField <= 3) {
//    return alert('Please add your city')
//   }

//   let toLowerCase = inputField.slice(1).toLowerCase()
//   let toUpperCase = inputField.slice(0,1).toUpperCase()
//   let alletters = toUpperCase + toLowerCase
//    let findCity = false
//    findCity = cities.includes(alletters)
//    if (findCity) {
//       findCity = true
//       document.getElementById('Result').innerHTML=alletters+' '+'Allredy in list'
//    }else{
     
//      cities.push(alletters)
    
//    }

// }
